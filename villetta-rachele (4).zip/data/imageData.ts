/**
 * @file data/imageData.ts
 * @purpose Defines the initial collection of images for the photo gallery, including metadata.
 */
import type { GalleryImage } from '../types';

/**
 * ISTRUZIONI PER AGGIUNGERE LE TUE FOTO:
 * 
 * 1.  Nella cartella principale del tuo progetto (accanto al file `index.html`), 
 *     crea una nuova cartella e chiamala `images`.
 * 
 * 2.  Dentro la cartella `images`, crea delle sottocartelle per ogni categoria di foto.
 *     Ad esempio: `camere`, `bagni`, `soggiorno`, `veranda`, `cucina`, `hero`, `location`.
 *     **IMPORTANTE**: Usa nomi di cartella tutti in minuscolo.
 * 
 * 3.  Copia le tue foto nelle sottocartelle appropriate.
 *     Esempio di struttura finale:
 *     - /images/soggiorno/foto_soggiorno_1.jpg
 *     - /images/camere/camera_matrimoniale_1.jpg
 * 
 * 4.  Modifica l'elenco `GALLERY_IMAGES` qui sotto per far corrispondere le tue foto.
 *     - `id`: Lascia che sia un numero unico per ogni foto.
 *     - `category`: Assicurati che il valore sia in **minuscolo** e corrisponda al nome della cartella.
 *     - `src`: Inserisci il percorso corretto alla tua foto, che inizia sempre con `/images/`.
 *     - `alt`: Un breve testo che descrive l'immagine (importante per l'accessibilità).
 *     - `description`: Una descrizione più lunga che apparirà sotto la foto nella galleria.
 * 
 * Esempio di un nuovo oggetto immagine da aggiungere all'elenco:
 * { 
 *   id: 23, 
 *   category: 'veranda', 
 *   src: '/images/veranda/veranda_con_dondolo.jpg', 
 *   alt: 'Dondolo in veranda', 
 *   description: 'Un comodo dondolo per rilassarsi all\'aperto.' 
 * },
 * 
 */

export const GALLERY_IMAGES: GalleryImage[] = [
  // Soggiorno
  { id: 1, category: 'soggiorno', src: '/images/soggiorno/soggiorno_01.jpg', alt: 'Soggiorno luminoso con divano', description: 'Ampio e comodo soggiorno con divano letto matrimoniale e TV a schermo piatto.' },
  { id: 2, category: 'soggiorno', src: '/images/soggiorno/soggiorno_02.jpg', alt: 'Angolo relax del soggiorno', description: 'Zona relax con poltrone e tavolino, perfetta per la lettura.' },
  { id: 3, category: 'soggiorno', src: '/images/soggiorno/soggiorno_03.jpg', alt: 'Dettaglio del soggiorno', description: 'Particolare dell\'arredamento del soggiorno.' },
  { id: 4, category: 'soggiorno', src: '/images/soggiorno/soggiorno_04.jpg', alt: 'Vista del soggiorno dall\'ingresso', description: 'Panoramica del soggiorno, spazioso e accogliente.' },
  { id: 5, category: 'soggiorno', src: '/images/soggiorno/soggiorno_05.jpg', alt: 'TV a schermo piatto', description: 'La zona TV per serate in famiglia.' },
  
  // Camere
  { id: 6, category: 'camere', src: '/images/camere/camera_01.jpg', alt: 'Camera da letto matrimoniale', description: 'Camera matrimoniale climatizzata con armadio capiente.' },
  { id: 7, category: 'camere', src: '/images/camere/camera_02.jpg', alt: 'Seconda camera da letto', description: 'Camera con due letti singoli, unibili in un matrimoniale su richiesta.' },
  { id: 8, category: 'camere', src: '/images/camere/camera_03.jpg', alt: 'Dettaglio letto matrimoniale', description: 'Lenzuola fresche e cuscini comodi per un riposo perfetto.' },
  { id: 9, category: 'camere', src: '/images/camere/camera_04.jpg', alt: 'Armadio camera', description: 'Spazioso armadio per riporre tutti i tuoi effetti personali.' },
  { id: 21, category: 'camere', src: '/images/camere/camera_05.jpg', alt: 'Finestra della camera', description: 'Luminosa finestra con vista sul giardino.' },

  // Cucina
  { id: 10, category: 'cucina', src: '/images/cucina/cucina_01.jpg', alt: 'Cucina moderna e attrezzata', description: 'Cucina completa di forno, frigorifero, piano cottura e stoviglie.' },
  { id: 11, category: 'cucina', src: '/images/cucina/cucina_02.jpg', alt: 'Dettaglio della cucina', description: 'Macchina da caffè, tostapane e bollitore a disposizione degli ospiti.' },
  { id: 12, category: 'cucina', src: '/images/cucina/cucina_03.jpg', alt: 'Piano cottura', description: 'Piano cottura a 4 fuochi per preparare deliziosi pasti.' },
  { id: 13, category: 'cucina', src: '/images/cucina/cucina_04.jpg', alt: 'Tavolo da pranzo', description: 'Tavolo da pranzo adiacente alla cucina.' },

  // Veranda
  { id: 14, category: 'veranda', src: '/images/veranda/veranda_01.jpg', alt: 'Veranda esterna con tavolo e sedie', description: 'Spaziosa veranda coperta, ideale per cene all\'aperto.' },
  { id: 15, category: 'veranda', src: '/images/veranda/veranda_02.jpg', alt: 'Vista dal giardino sulla veranda', description: 'La veranda si affaccia sul giardino privato della villetta.' },
  { id: 16, category: 'veranda', src: '/images/veranda/veranda_03.jpg', alt: 'Area relax in veranda', description: 'Comode sedute per godersi il fresco della sera.' },

  // Bagni
  { id: 17, category: 'bagni', src: '/images/bagni/bagno1_01.jpg', alt: 'Bagno principale con doccia', description: 'Bagno principale con box doccia, lavabo e servizi.' },
  { id: 18, category: 'bagni', src: '/images/bagni/bagno1_02.jpg', alt: 'Box doccia del bagno principale', description: 'Ampio box doccia nel bagno principale.' },
  { id: 19, category: 'bagni', src: '/images/bagni/bagno1_03.jpg', alt: 'Lavabo del bagno principale', description: 'Dettaglio del lavabo e dello specchio.' },
  { id: 20, category: 'bagni', src: '/images/bagni/bagno2_01.jpg', alt: 'Secondo bagno di servizio', description: 'Secondo bagno di servizio, comodo e funzionale.' },
  { id: 22, category: 'bagni', src: '/images/bagni/bagno2_02.jpg', alt: 'Dettaglio del secondo bagno', description: 'WC e lavandino del bagno di servizio.' },
];